from dataclasses import fields
# from dataclasses import fields

from dataclasses import fields
from rest_framework import serializers

from .models import Book

class Itemsel(serializers.ModelSerializer):
    # password = serializers.CharField()
    class Meta:
        model = Book
        # fields = '__all__'
        fields = ['name','author_name','admin_id','image']

        