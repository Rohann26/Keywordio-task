
from django import forms
from django.db.models import fields
from .models import Admin
from django.forms.widgets import PasswordInput
from django.contrib.auth.hashers import check_password

class Adminsignup(forms.ModelForm):
    password = forms.CharField(widget=PasswordInput)
    confirm_password = forms.CharField(widget=PasswordInput)
    class Meta:
        model = Admin
        fields = ['name', 'email', 'phone']

    def clean(self):
        p = self.cleaned_data.get('password')
        p1 = self.cleaned_data.get('confirm_password')
        if p != p1 or len(p) <6:
            forms.ValidationError("both passwords did not match, password length should be more than 6")
        

class Adminsignin(forms.Form):
    email = forms.CharField()
    password = forms.CharField(widget=PasswordInput)
    def clean(self):
        e = self.cleaned_data.get('email')
        p = self.cleaned_data.get('password')
        try:
            admin = Admin.objects.get(email = e)
        except:
            raise forms.ValidationError("Admin Email does not exist")
        else:
            if not check_password(p,admin.password):
                raise forms.ValidationError("Password does not match")

