

from dataclasses import fields
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.shortcuts import render
from library.forms import Adminsignin, Adminsignup
from .models import Admin, Book
from django.contrib.auth.hashers import make_password
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from urllib import request
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .serialize import Itemsel
# Create your views here.


def adminregister(request):
    x = Adminsignup(request.POST or None)
    if x.is_valid():
        admindata = x.save(commit=False)
        p = x.cleaned_data.get('password')
        p1 = make_password(p)
        admindata.password = p1
        admindata.save()
        return redirect('library:adminlogin')
    return render(request, 'library/adminform.html',{'form':x})

def adminlogin(request):
    x = Adminsignin(request.POST or None)
    if x.is_valid():
        e = x.cleaned_data.get('email')
        obj = Admin.objects.get(email = e)
        request.session['user']= {'admin_name':obj.name,'admin_email':obj.email}
        return redirect('library:home')
    return render(request,'library/adminform.html',{'form':x})

class Home(ListView):
    template_name = 'library/adminhome.html'
    context_object_name = 'books'
    def get_queryset(self):
        adminid = self.request.session.get('user')
        if adminid:
            adm = Admin.objects.get(email = adminid.get('admin_email'))
            return{'boks':adm.book_set.all()}
        
        else:
            return {'boks':Book.objects.all()}

def logout(request):
    request.session.pop('user')
    return redirect('library:home')


class Addbook(CreateView):
    template_name = 'library/addbook.html'
    model = Book
    fields = ['name','author_name','image']
    context_object_name = 'form'
    def form_valid(self, form):
        adminid = self.request.session.get('user')
        if adminid:
            adm = Admin.objects.get(email = adminid.get('admin_email'))
            form.instance.admin_id = adm
            return super().form_valid(form)
        else:
            return None
    

class Updatebook(UpdateView):
    template_name = 'library/addbook.html'
    model = Book
    fields = ['name','author_name', 'image']
    context_object_name = 'form'


class Deletebook(DeleteView):
    template_name = 'library/delbook.html'
    model = Book
    context_object_name = 'book'
    success_url = reverse_lazy('library:home')


###########################################################

@api_view(["GET"])
def allitems(request):
    a = Book.objects.all()
    ser = Itemsel(a,many = True)
    return Response(ser.data)


@api_view(["GET"])
def single(request,pk):
    try:
        a = Book.objects.get(id = pk)
    except:
        return Response("the queried data does not exist")
    ser = Itemsel(a)
    return Response(ser.data)


@api_view(["POST"])
def adddata(request):
    a = Itemsel(data=request.data)
    if a.is_valid():
        a.save()
    return Response(a.data)


@api_view(["PUT"])
def updata(request,pk):
    try:
        a = Book.objects.get(id = pk)
        ser = Itemsel(instance=a, data= request.data)
    except:
        ser = Itemsel(data= request.data)
    if ser.is_valid(raise_exception=True):   
        ser.save()
    return Response(ser.data)


@api_view(["DELETE"])
def deldata(request,pk):
    a = Book.objects.get(id = pk)
    a.delete()
    return Response("Item deleted successfully") 

