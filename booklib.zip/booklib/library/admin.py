from django.contrib import admin
from .models import Admin, Book

admin.site.register(Admin)
admin.site.register(Book)

# Register your models here.
