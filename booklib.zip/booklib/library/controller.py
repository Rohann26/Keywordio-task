from django.urls import path
from . import views

app_name = 'library'
urlpatterns = [
    path('',views.Home.as_view(),name='home'),
    path('adminregister/',views.adminregister,name='adminregister'),
    path('adminlogin/',views.adminlogin,name='adminlogin'),
    path('logout/',views.logout,name='logout'),
    path('addbook/',views.Addbook.as_view(),name='addbook'),
    path('updatebook/<int:pk>',views.Updatebook.as_view(),name='updatebook'),
    path('deletebook/<int:pk>',views.Deletebook.as_view(),name='deletebook'),
    path("all/", views.allitems),
    path("view/<int:pk>",views.single),
    path("create",views.adddata),
    path("up/<int:pk>",views.updata),
    path("del/<int:pk>",views.deldata),
]