
from django.urls import reverse
from django.db.models.deletion import CASCADE
from django.db import models
from django.db.models.fields import EmailField


class Admin(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=10)
    password = models.CharField(max_length=100, default=0)
    

    def __str__(self):
        return f'{self.name}'

class Book(models.Model):
    name = models.CharField(max_length=100)
    author_name = models.CharField(max_length=100)
    admin_id = models.ForeignKey(Admin,on_delete=CASCADE)
    image = models.FileField()

    def __str__(self):
        return f'{self.name}'
    def get_absolute_url(self):
        return reverse('library:home')



